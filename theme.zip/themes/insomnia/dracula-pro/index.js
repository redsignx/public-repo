module.exports.themes = [
  require("./alucard"),
  require("./blade"),
  require("./buffy"),
  require("./lincoln"),
  require("./morbius"),
  require("./pro"),
  require("./van-helsing"),
];
