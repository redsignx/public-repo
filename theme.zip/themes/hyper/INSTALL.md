### [Hyper](https://hyper.is/)

#### Installation

1. Copy the desired variant or all variants from the `variants` folder;
2. Paste them into `~/.hyper_plugins/local`;
3. Open the `~/.hyper.js` file;
4. Add the desired variant to the local plugins list like this:

```js
localPlugins: ["dracula-pro"];
```

#### Activating theme

1. Start or restart Hyper;
2. Boom, it's working! 😊
