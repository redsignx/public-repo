### [Slack](https://slack.com/)

#### Install

1. Go to `Preferences > Themes`;
2. Select the desired **Color Mode**, (eg: light mode for Alucard;)
3. In the **Custom Theme** section, copy the values from the desired variant below and paste them.

- **Alucard**: `#F5F5F5,#635D97,#14710A,#A3144D`;
- **Blade**: `#212C2A,#70A99F,#8AFF80,#FF80BF`;
- **Buffy**: `#2A212C,#9F70A9,#8AFF80,#FF80BF`;
- **Lincoln**: `#2C2A21,#A99F70,#8AFF80,#FF80BF`;
- **Morbius**: `#2C2122,#A97079,#8AFF80,#FF80BF`;
- **Pro**: `#22212C,#7970A9,#8AFF80,#FF80BF`;
- **Van Helsing**: `#0B0D0F,#708CA9,#8AFF80,#FF80BF`;
