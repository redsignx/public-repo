### [iTerm 2](https://www.iterm2.com/)

#### Activating theme

1.  Go to `Preferences > Profiles > Colors` tab
2.  Open the _Color Presets..._ drop-down in the bottom right corner
3.  Select _Import..._ from the list
4.  Select the `dracula-pro.itermcolors` file
5.  Select the _Dracula Pro_ from _Color Presets..._
