### [Mozilla Firefox](https://www.mozilla.org/en-US/firefox)

#### Activating theme

1. Type `about:addons` in the address bar.
2. Go to Themes and click on the "gear" icon
3. Select the "Install Add-on From File..." option
4. Choose the `dracula-pro.xpi` file
